<?php
/*
Plugin Name: UE FPS Specials
Plugin URI: https://ueeng.com
Description: This plugin adds functionality for FPS
Version: 1.0.0
Author: UEEng
Author URI: https://ueeng.com/
*/



function ueeng_register_cpt_instagram() {
	$labels = array(
		"name" => __( "Instagram", "custom-post-type-ui" ),
		"singular_name" => __( "Instagram", "custom-post-type-ui" ),
		"menu_name" => __( "Instagram-Posts", "custom-post-type-ui" ),
	);

	$args = array(
		"label" => __( "Instagram", "custom-post-type-ui" ),
		"labels" => $labels,
		"description" => "Instagram Posts der Freien Privatschule Zürich",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => "news",
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "instagram", "with_front" => true ),
		"query_var" => true,
		"supports" => array( "title", "thumbnail", "excerpt" ),
	);

	register_post_type( "instagram", $args );
}

add_action('init', 'ueeng_register_cpt_instagram');
