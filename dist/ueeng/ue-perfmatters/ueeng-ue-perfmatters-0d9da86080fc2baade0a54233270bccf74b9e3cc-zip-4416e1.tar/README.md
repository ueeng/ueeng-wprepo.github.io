# UE Perfmatters

# Steps to Update
1. Load current version from perfmatters.io
2. Update files in this Repro
3. Comment line 53 (or similar) "add_action('admin_init', 'perfmatters_edd_plugin_updater', 0);"
4. Add git release with version from plugin